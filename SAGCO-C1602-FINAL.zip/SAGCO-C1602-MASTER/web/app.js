// app.js — SAGCO C-1602-O-1B Field Dashboard
// Reads web/data/project.json, isos.json, variance.json
// If files not found: falls back to embedded GEN-001 baseline data

const FALLBACK = {
  project: {
    circuit:"C-1602-O-1B", facility:"LyondellBasell CC", process:"Liquid Furnace Feed",
    total_isos:57, isos_complete:12, completion_pct:21.05,
    rbic_clouds_total:116, rbic_charged:43, rbic_pct:37.07,
    rope_isos_total:29, rope_done:0, rope_pct:0.0,
    hours_budget:1080, hours_used:618.3, hours_remaining:461.7,
    compliance_pct:85.1, eru_score:851, audit_status:"PASS", risk_level:"MEDIUM",
    fitness:0.306, resonance_f:0.041, resonance_status:"CAPACITIVE_DOMINANT",
    generation:1, timestamp:"2026-06-08", permit:"CC-GWP-26-717369",
    supervisor:"Domenic Garza SPRAT L3 #2300689"
  },
  variance: {
    iso_expected:57, iso_actual:12, iso_delta:45, iso_pct:21.1,
    rbic_expected:116, rbic_actual:43, rbic_delta:73, rbic_pct:37.1,
    rope_expected:29, rope_actual:0, rope_delta:29, rope_pct:0.0,
    eru_expected:90.0, eru_actual:85.1, eru_delta:4.9, eru_pct:94.6,
    hrs_budget:1080, hrs_used:618.3, hrs_remaining:461.7, hrs_pct:57.2,
    fitness:0.306, resonance_f:0.041, L:29, C:73
  }
};

const FURNACE_COLORS = {
  A:"#ef4444",B:"#f97316",C:"#eab308",D:"#84cc16",E:"#22c55e",
  F:"#14b8a6",G:"#06b6d4",H:"#3b82f6",J:"#8b5cf6",K:"#d946ef",
  L:"#f43f5e",M:"#fb923c",N:"#a3e635"
};

async function loadJSON(path) {
  try {
    const r = await fetch(path);
    if (!r.ok) throw new Error();
    return await r.json();
  } catch { return null; }
}

async function init() {
  const proj = (await loadJSON('data/project.json')) || FALLBACK.project;
  const vari = (await loadJSON('data/variance.json')) || FALLBACK.variance;
  const isos = (await loadJSON('data/isos.json'));

  render(proj, vari, isos);
}

function render(p, v, isosData) {
  // ── KPIs ────────────────────────────────────────────────
  const kpis = [
    { id:'kpi-iso',   val:`${p.isos_complete}/${p.total_isos}`, sub:`${p.completion_pct.toFixed(1)}% ISOs`, cls:'blue' },
    { id:'kpi-rbic',  val:`${p.rbic_charged}`,                  sub:`of ${p.rbic_clouds_total} clouds`,    cls:'yellow' },
    { id:'kpi-rope',  val:`${p.rope_done}/${p.rope_isos_total}`,sub:'rope access',                         cls: p.rope_pct > 50 ? 'green' : 'red' },
    { id:'kpi-eru',   val:`${p.eru_score}`,                     sub:`${p.audit_status} · ${p.risk_level}`, cls: p.compliance_pct >= 90 ? 'green' : 'yellow' },
    { id:'kpi-hrs',   val:`${p.hours_remaining.toFixed(0)}`,    sub:'hrs remaining',                       cls: p.hours_remaining < 100 ? 'red' : 'cyan' },
    { id:'kpi-fit',   val:`${(p.fitness*100).toFixed(1)}%`,     sub:'fitness score',                       cls: p.fitness > 0.7 ? 'green' : 'yellow' },
  ];

  kpis.forEach(k => {
    const el = document.getElementById(k.id);
    if (!el) return;
    el.querySelector('.kpi-value').textContent = k.val;
    el.querySelector('.kpi-sub').textContent = k.sub;
    el.className = `kpi ${k.cls}`;
  });

  // ── BRANCH BARS ─────────────────────────────────────────
  const branches = [
    { id:'br-iso',   pct: p.completion_pct,  color:'#3b82f6', label:`${p.isos_complete}/${p.total_isos}` },
    { id:'br-rbic',  pct: p.rbic_pct,        color:'#ef4444', label:`${p.rbic_charged}/${p.rbic_clouds_total}` },
    { id:'br-rope',  pct: p.rope_pct,        color:'#8b5cf6', label:`${p.rope_done}/${p.rope_isos_total}` },
    { id:'br-eru',   pct: p.compliance_pct,  color:'#22c55e', label:`${p.compliance_pct}%` },
  ];

  branches.forEach(b => {
    const row = document.getElementById(b.id);
    if (!row) return;
    row.querySelector('.branch-fill').style.width = `${b.pct}%`;
    row.querySelector('.branch-fill').style.background = b.color;
    row.querySelector('.branch-pct').textContent = `${b.pct.toFixed(1)}%`;
    row.querySelector('.branch-pct').style.color = b.color;
    row.querySelector('.branch-count').textContent = b.label;
  });

  // ── RESONANCE ───────────────────────────────────────────
  const fPct = (p.resonance_f / 1.0) * 100;
  const resFill = document.getElementById('resonance-fill');
  if (resFill) {
    resFill.style.width = `${Math.max(fPct, 2)}%`;
  }
  const resVal = document.getElementById('resonance-val');
  if (resVal) resVal.textContent = `f = ${p.resonance_f.toFixed(4)}`;
  const resStat = document.getElementById('resonance-status');
  if (resStat) {
    resStat.textContent = p.resonance_status.replace(/_/g,' ');
    resStat.style.color = p.resonance_f > 0.7 ? '#22c55e' : p.resonance_f > 0.3 ? '#eab308' : '#ef4444';
  }

  // ── VARIANCE TABLE ──────────────────────────────────────
  const tbody = document.getElementById('var-tbody');
  if (tbody) {
    const rows = [
      ['ISOs complete', v.iso_expected, v.iso_actual, v.iso_delta, v.iso_pct],
      ['RBIC clouds',   v.rbic_expected, v.rbic_actual, v.rbic_delta, v.rbic_pct],
      ['Rope ISOs',     v.rope_expected, v.rope_actual, v.rope_delta, v.rope_pct],
      ['ERU %',         v.eru_expected, v.eru_actual, v.eru_delta, v.eru_pct],
      ['Hours',         v.hrs_budget, v.hrs_used, v.hrs_remaining, v.hrs_pct],
    ];
    tbody.innerHTML = rows.map(([name, exp, act, delta, pct]) => {
      const cls = pct >= 80 ? 'delta-good' : pct >= 40 ? 'delta-warn' : 'delta-bad';
      return `<tr>
        <td>${name}</td>
        <td>${exp.toFixed(1)}</td>
        <td>${act.toFixed(1)}</td>
        <td class="${cls}">${delta.toFixed(1)}</td>
        <td class="${cls}">${pct.toFixed(1)}%</td>
      </tr>`;
    }).join('');
  }

  // ── ISO GRID ────────────────────────────────────────────
  const isoGrid = document.getElementById('iso-grid');
  if (isoGrid) {
    const isoArr = isosData ? isosData.isos : [];
    // Build from data or generate stubs
    const data = isoArr.length ? isoArr : Array.from({length:57}, (_,i) => ({
      iso: i+1,
      furnace: ['A','A','A','B','B','B','C','C','C','C','C',
                'D','D','D','D','D','E','E','E','E','E',
                'F','F','F','F','F','G','G','G','G','G',
                'H','H','H','H','H','J','J','J','J','J',
                'K','K','K','L','L','L','M','M','M','M','M',
                'N','N','N','N','N'][i],
      rbic_total: 2, rope_req: i < 29, complete: i < 12, rbic_done: i < 12 ? 2 : 0
    }));

    isoGrid.innerHTML = data.map(d => {
      const fColor = FURNACE_COLORS[d.furnace] || '#888';
      const cls = d.complete ? 'iso-cell complete' : d.rope_req ? 'iso-cell rope-req' : 'iso-cell';
      const cloudBar = d.rbic_done >= d.rbic_total ? '●' : d.rbic_done > 0 ? '◐' : '○';
      return `<div class="${cls}" style="border-color:${d.complete ? fColor+'44' : '#1e1e3a'}" title="ISO ${d.iso} · Furnace ${d.furnace}">
        <span class="iso-num" style="color:${fColor}">${String(d.iso).padStart(2,'0')}</span>
        <span class="iso-furnace">${d.furnace} ${cloudBar}</span>
      </div>`;
    }).join('');
  }

  // ── HEADER STATUS ───────────────────────────────────────
  const ts = document.getElementById('timestamp');
  if (ts) ts.textContent = p.timestamp || '2026-06-08';
  const gen = document.getElementById('generation');
  if (gen) gen.textContent = `GEN-00${p.generation || 1}`;
}

document.addEventListener('DOMContentLoaded', init);
