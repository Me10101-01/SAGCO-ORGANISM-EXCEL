# Brock Trackers — Absorbed Source
## What lives here
- Original Brock Excel files (.xlsx) — DO NOT MODIFY
- These are EXECUTION TRUTH: hours, costs, packages, crew, status
- SAGCO reads these as source; never overwrites them

## Absorb process
sagco c1602 ingest → reads these → populates project.yaml:rope_access block
and tracker/cost_tracker.xlsx via the brock-to-sagco bridge

## Fields absorbed
hours_budget, hours_used, hours_remaining, cost, package, crew, daily_production
