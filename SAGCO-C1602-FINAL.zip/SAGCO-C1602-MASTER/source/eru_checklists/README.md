# ERU Checklists — Absorbed Source
## What lives here
- ROPE_ACCESS_ERU_COMPLIANCE_ENGINE_v0_1.xlsx
- ROPE_ACCESS_LEVEL3_RESPONSIBILITY_CHECKLIST_ICOP_REFERENCED.docx

## This is COMPLIANCE TRUTH
47 items | ICOP July 2014 | SPRAT L3 | Permit CC-GWP-26-717369
Current state: 40 Verified | 4 Complete | 3 In Progress (blockers: 5, 35, 46)

## Fields absorbed
item_id, section, status, icop_ref, evidence, date_verified, verified_by
