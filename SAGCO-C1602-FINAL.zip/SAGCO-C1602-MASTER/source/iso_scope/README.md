# ISO Scope — Absorbed Source
## What lives here
- 230213_C1602O1B_CUI_SCOPE.pdf (102 pages, 57 ISOs + field photos)
- Extracted iso wafers → wafers/isos/

## Fields extracted per ISO
iso_num, furnace, line_no, pipe_size, rbic_cloud_count, rope_required,
material, insulated, oper_psi, oper_temp, p_and_id_ref

## Extraction confidence
92% (OCR on raster PDF — ~8% inferred from furnace pattern)
