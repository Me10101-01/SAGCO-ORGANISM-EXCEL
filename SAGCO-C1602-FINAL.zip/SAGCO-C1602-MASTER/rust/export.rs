// export.rs — YAML wafer → JSON export engine
// sagco c1602 export
// Reads project state → writes output/project.json, isos.json, variance.json

use std::fs;
use std::path::Path;

pub fn run() {
    println!("\n[EXPORT] YAML → JSON pipeline starting...");

    fs::create_dir_all("output").unwrap_or_default();

    export_project();
    export_isos();
    export_variance();

    println!("[EXPORT] Complete — 3 JSON files written to output/");
}

fn export_project() {
    // Reads project.yaml state → project.json
    // In GEN001: values hardcoded from wafer scan
    // In GEN002: parse project.yaml with serde_yaml
    let json = serde_json_manual(&[
        ("circuit",           "\"C-1602-O-1B\""),
        ("facility",          "\"LyondellBasell Corpus Christi\""),
        ("process",           "\"Liquid Furnace Feed\""),
        ("area",              "11"),
        ("total_isos",        "57"),
        ("isos_complete",     "12"),
        ("completion_pct",    "21.05"),
        ("rbic_clouds_total", "116"),
        ("rbic_charged",      "43"),
        ("rbic_pct",          "37.07"),
        ("rope_isos_total",   "29"),
        ("rope_done",         "0"),
        ("rope_pct",          "0.0"),
        ("hours_budget",      "1080.0"),
        ("hours_used",        "618.3"),
        ("hours_remaining",   "461.7"),
        ("compliance_pct",    "85.1"),
        ("eru_score",         "851"),
        ("audit_status",      "\"PASS\""),
        ("risk_level",        "\"MEDIUM\""),
        ("fitness",           "0.306"),
        ("resonance_f",       "0.041"),
        ("resonance_status",  "\"CAPACITIVE_DOMINANT\""),
        ("generation",        "1"),
        ("timestamp",         "\"2026-06-08\""),
        ("permit",            "\"CC-GWP-26-717369\""),
        ("supervisor",        "\"Domenic Garza SPRAT L3 #2300689\""),
    ]);
    write_json("output/project.json", &json);
    println!("  ✓ output/project.json");
}

fn export_isos() {
    // 57 ISO records — pipe_size, furnace, line, rbic totals, rope req
    let iso_data: Vec<(u32,&str,&str,u32,u32,bool)> = vec![
        (1,"A","4\"-0-161144A-B1B",4,2,true),
        (2,"A","3\"-0-161144A-B1B",3,2,true),
        (3,"A","6\"-0-161003A-B1B",6,3,true),
        (4,"B","4\"-0-161144B-B1B",4,2,true),
        (5,"B","3\"-0-161144B-B1B",3,2,true),
        (6,"B","6\"-0-161003B-B1B",6,3,true),
        (7,"C","4\"-0-161144CA-B33B",4,2,true),
        (8,"C","3\"-0-161144CB-B33B",3,2,true),
        (9,"C","6\"-0-161003CA-B33B",6,3,true),
        (10,"C","3\"-0-161144CC-B33B",3,1,false),
        (11,"C","6\"-0-161003CB-B33B",6,2,false),
        (12,"D","4\"-0-161144DA-B33B",4,2,true),
        (13,"D","3\"-0-161144DB-B33B",3,2,true),
        (14,"D","6\"-0-161003DA-B33B",6,3,true),
        (15,"D","3\"-0-161144DC-B33B",3,1,false),
        (16,"D","6\"-0-161003DB-B33B",6,2,false),
        (17,"E","4\"-0-161144E-B1B",4,2,true),
        (18,"E","3\"-0-161144EA-B33A",3,2,true),
        (19,"E","6\"-0-161003EA-B33B",6,3,true),
        (20,"E","3\"-0-161144EB-B33A",3,2,false),
        (21,"E","6\"-0-161003EB-B33B",6,2,false),
        (22,"F","4\"-0-161144F-B1B",4,2,true),
        (23,"F","3\"-0-161144FA-B33A",3,2,true),
        (24,"F","6\"-0-161003FA-B33B",6,3,true),
        (25,"F","3\"-0-161144FB-B33A",3,2,false),
        (26,"F","6\"-0-161003FB-B33B",6,2,false),
        (27,"G","4\"-0-161144G-B1B",4,2,true),
        (28,"G","3\"-0-161144GA-B33A",3,2,true),
        (29,"G","6\"-0-161003GA-B33B",6,3,true),
        (30,"G","3\"-0-161144GB-B33A",3,1,false),
        (31,"G","6\"-0-161003GB-B33B",6,2,false),
        (32,"H","4\"-0-161144H-B1B",4,2,true),
        (33,"H","3\"-0-161144HA-B33A",3,2,true),
        (34,"H","6\"-0-161003HA-B33B",6,3,true),
        (35,"H","3\"-0-161144HB-B33A",3,2,false),
        (36,"H","6\"-0-161003HB-B33B",6,2,false),
        (37,"J","4\"-0-161144J-B1B",4,2,true),
        (38,"J","3\"-0-161144JA-B33A",3,2,true),
        (39,"J","6\"-0-161003JA-B33B",6,3,true),
        (40,"J","3\"-0-161144JB-B33A",3,1,false),
        (41,"J","6\"-0-161003JB-B33B",6,2,false),
        (42,"K","4\"-0-161144K-B1B",4,2,true),
        (43,"K","3\"-0-161144KA-B33A",3,2,true),
        (44,"K","6\"-0-161003K-B1B",6,3,false),
        (45,"L","4\"-0-161144L-B1B",4,2,true),
        (46,"L","3\"-0-161144LA-B33A",3,2,true),
        (47,"L","6\"-0-161003L-B1B",6,3,false),
        (48,"M","4\"-0-161144M-B1B",4,2,true),
        (49,"M","3\"-0-161144MA-B33A",3,2,true),
        (50,"M","6\"-0-161003MA-B1D",6,3,false),
        (51,"M","3\"-0-161144MB-B33A",3,1,false),
        (52,"M","6\"-0-161003MB-B1D",6,2,false),
        (53,"N","4\"-0-161144N-B1B",4,2,true),
        (54,"N","3\"-0-161144NA-B33A",3,2,true),
        (55,"N","6\"-0-161003NA-B1D",6,3,false),
        (56,"N","3\"-0-161144NB-B33A",3,1,false),
        (57,"N","6\"-0-161003NB-B1D",6,2,false),
    ];

    let mut records = Vec::new();
    for (iso, furnace, line, pipe, rbic, rope) in &iso_data {
        records.push(format!(
            "  {{\"iso\":{},\"furnace\":\"{}\",\"line\":\"{}\",\"pipe_in\":{},\"rbic_total\":{},\
            \"rope_req\":{},\"rbic_done\":0,\"rope_done\":false,\"vi_done\":false,\
            \"complete\":false,\"hours\":0.0}}",
            iso, furnace, line, pipe, rbic, rope
        ));
    }

    let json = format!("{{\n  \"circuit\":\"C-1602-O-1B\",\n  \"total\":{},\n  \"isos\":[\n{}\n  ]\n}}",
        iso_data.len(), records.join(",\n"));
    write_json("output/isos.json", &json);
    println!("  ✓ output/isos.json ({} ISO records)", iso_data.len());
}

fn export_variance() {
    let json = serde_json_manual(&[
        ("circuit",        "\"C-1602-O-1B\""),
        ("timestamp",      "\"2026-06-08\""),
        ("iso_expected",   "57"),
        ("iso_actual",     "12"),
        ("iso_delta",      "45"),
        ("iso_pct",        "21.1"),
        ("rbic_expected",  "116"),
        ("rbic_actual",    "43"),
        ("rbic_delta",     "73"),
        ("rbic_pct",       "37.1"),
        ("rope_expected",  "29"),
        ("rope_actual",    "0"),
        ("rope_delta",     "29"),
        ("rope_pct",       "0.0"),
        ("eru_expected",   "90.0"),
        ("eru_actual",     "85.1"),
        ("eru_delta",      "4.9"),
        ("eru_pct",        "94.6"),
        ("hrs_budget",     "1080.0"),
        ("hrs_used",       "618.3"),
        ("hrs_remaining",  "461.7"),
        ("hrs_pct",        "57.2"),
        ("burn_rate_iso",  "51.52"),
        ("fitness",        "0.306"),
        ("resonance_f",    "0.041"),
        ("L",              "29"),
        ("C",              "73"),
        ("resonance_status","\"CAPACITIVE_DOMINANT\""),
    ]);
    write_json("output/variance.json", &json);
    println!("  ✓ output/variance.json");
}

// ── Minimal JSON builder (zero deps) ────────────────────────────────
fn serde_json_manual(fields: &[(&str, &str)]) -> String {
    let mut out = String::from("{\n");
    for (i, (k, v)) in fields.iter().enumerate() {
        let comma = if i < fields.len() - 1 { "," } else { "" };
        out.push_str(&format!("  \"{}\": {}{}\n", k, v, comma));
    }
    out.push('}');
    out
}

fn write_json(path: &str, content: &str) {
    fs::write(path, content).expect(&format!("Failed to write {}", path));
}
