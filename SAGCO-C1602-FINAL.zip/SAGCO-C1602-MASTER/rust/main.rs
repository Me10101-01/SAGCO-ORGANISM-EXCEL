// SAGCO-C1602-MASTER — Sovereign Field Intelligence Engine
// cargo run [command]
// Commands: ingest | iso | cloud | eru | variance | resonance | export | dashboard | full

use std::env;

mod ingest;
mod variance;
mod resonance;
mod iso;
mod cloud;
mod eru;
mod export;
mod dashboard;

fn banner() {
    println!("╔═══════════════════════════════════════════════════════╗");
    println!("║  SAGCO C-1602-O-1B MASTER ENGINE v1.0                 ║");
    println!("║  4 Truth Pillars: Brock | ISO | ERU | SAGCO            ║");
    println!("╚═══════════════════════════════════════════════════════╝");
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let command = args.get(1).map(|s| s.as_str()).unwrap_or("full");

    banner();

    match command {
        "ingest"    => ingest::run(),
        "iso"       => iso::run(),
        "cloud"     => cloud::run(),
        "eru"       => eru::run(),
        "variance"  => variance::run(),
        "resonance" => resonance::run(),
        "export"    => export::run(),
        "dashboard" => dashboard::run(),
        "full" => {
            ingest::run();
            iso::run();
            cloud::run();
            eru::run();
            variance::run();
            resonance::run();
            export::run();
            dashboard::run();
        }
        _ => eprintln!("Commands: ingest|iso|cloud|eru|variance|resonance|export|dashboard|full"),
    }
}
