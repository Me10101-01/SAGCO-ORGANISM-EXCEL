// resonance.rs — LC circuit resonance model
// L = rope load (inductive) | C = RBIC backlog (capacitive)
// f = 1/(2π√LC)

use std::f64::consts::PI;

pub fn run() {
    println!("\n[RESONANCE] Computing LC field balance...");

    let l: f64 = 29.0;   // rope ISOs remaining
    let c: f64 = 73.0;   // RBIC clouds remaining

    let f_raw  = 1.0 / (2.0 * PI * (l * c).sqrt());
    let f_max  = 1.0 / (2.0 * PI);   // L=1, C=1 perfect balance
    let f_norm = (f_raw / f_max).min(1.0);

    let status = if f_norm < 0.3      { "CAPACITIVE DOMINANT — C >> L, slow burn" }
                 else if f_norm < 0.7  { "APPROACHING BALANCE" }
                 else                  { "RESONANT — optimal burn rhythm" };

    println!("  L (rope remaining):    {}", l);
    println!("  C (clouds remaining):  {}", c);
    println!("  f (normalized):        {:.4}", f_norm);
    println!("  Status:                {}", status);
    println!("  Target:                f > 0.7 (approaching resonance)");
    println!("  Physics:               f = 1 / (2π√LC)");

    // Fitness composite
    let compliance = 0.851f64;
    let iso_pct    = 12.0f64 / 57.0;
    let rbic_pct   = 43.0f64 / 116.0;
    let rope_pct   = 0.0f64;

    let fitness = 0.30 * compliance
                + 0.25 * f_norm
                + 0.25 * iso_pct
                + 0.10 * rbic_pct
                + 0.10 * rope_pct;

    println!("  Fitness:               {:.3} ({:.1}%)", fitness, fitness * 100.0);
    println!("[RESONANCE] Complete");
}
