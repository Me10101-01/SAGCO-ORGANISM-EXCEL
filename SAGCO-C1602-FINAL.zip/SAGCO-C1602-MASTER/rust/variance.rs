// variance.rs — Expected vs Actual vs Delta

pub fn run() {
    println!("\n[VARIANCE] Computing expected / actual / delta...");

    struct Metric { name: &'static str, expected: f64, actual: f64 }

    let metrics = vec![
        Metric { name: "ISOs complete",    expected: 57.0,  actual: 12.0  },
        Metric { name: "RBIC clouds",      expected: 116.0, actual: 43.0  },
        Metric { name: "Rope ISOs",        expected: 29.0,  actual: 0.0   },
        Metric { name: "ERU compliance %", expected: 90.0,  actual: 85.1  },
        Metric { name: "Hours used",       expected: 1080.0,actual: 618.3 },
    ];

    println!("  {:22} {:>10} {:>10} {:>10} {:>8}", "METRIC","EXPECTED","ACTUAL","DELTA","DELTA%");
    println!("  {}", "─".repeat(65));
    for m in &metrics {
        let delta = m.expected - m.actual;
        let pct   = (m.actual / m.expected) * 100.0;
        println!("  {:22} {:>10.1} {:>10.1} {:>10.1} {:>7.1}%",
            m.name, m.expected, m.actual, delta, pct);
    }
    println!("[VARIANCE] Complete");
}
