// dashboard.rs — Generate web/data/ JSON + print ASCII dashboard
// sagco c1602 dashboard

use std::fs;

pub fn run() {
    print_dashboard();
    write_web_data();
}

fn print_dashboard() {
    let iso_pct    = 21.1f32;
    let rbic_pct   = 37.1f32;
    let rope_pct   = 0.0f32;
    let eru_pct    = 85.1f32;
    let hrs_left   = 461.7f32;
    let fitness    = 30.6f32;
    let resonance  = 0.041f32;

    println!("\n╔═══════════════════════════════════════════════════════════════╗");
    println!("║  SAGCO C-1602-O-1B  ·  DASHBOARD  ·  GEN-001  ·  2026-06-08  ║");
    println!("╠═══════════════════════════════════════════════════════════════╣");
    println!("║  Circuit: C-1602-O-1B  ·  LyondellBasell  ·  205 PSI / 203°F ║");
    println!("╠═══════════════════════════════════════════════════════════════╣");

    println!("║                                                               ║");
    bar("ISO  Complete ", iso_pct,  "12/57",   "██");
    bar("RBIC Clouds   ", rbic_pct, "43/116",  "██");
    bar("Rope Access   ", rope_pct, "0/29",    "░░");
    bar("ERU Compliance", eru_pct,  "40/47",   "██");

    println!("║                                                               ║");
    println!("╠═══════════════════════════════════════════════════════════════╣");
    println!("║  VARIANCE TABLE                                               ║");
    println!("║  ─────────────────────────────────────────────────────────── ║");
    println!("║  ISOs:    expected 57   actual 12   delta 45   (21.1%)        ║");
    println!("║  Clouds:  expected 116  actual 43   delta 73   (37.1%)        ║");
    println!("║  Rope:    expected 29   actual 0    delta 29   (0.0%)         ║");
    println!("║  Hours:   budget 1080   used 618.3  left 461.7 (57.2%)       ║");
    println!("╠═══════════════════════════════════════════════════════════════╣");
    println!("║  RESONANCE  f = 1/(2π√LC)                                     ║");
    println!("║  L={:<4}  C={:<4}  f={:.4}  → CAPACITIVE DOMINANT            ║", 29, 73, resonance);
    println!("║  Fitness: {:.1}%  ·  Hours left: {:.1}  ·  Blockers: 3      ║", fitness, hrs_left);
    println!("╠═══════════════════════════════════════════════════════════════╣");
    println!("║  NEXT BRICK:                                                  ║");
    println!("║  1. File daily report → kill ERU blocker #46                  ║");
    println!("║  2. Complete client training → advance ERU #5                 ║");
    println!("║  3. Log 8 ISOs today → f target 0.25 by EOD                   ║");
    println!("╚═══════════════════════════════════════════════════════════════╝");
}

fn bar(label: &str, pct: f32, count: &str, fill: &str) {
    let filled = (pct / 5.0).round() as usize;  // 20 char bar
    let empty  = 20usize.saturating_sub(filled);
    let bar_str = fill.repeat(filled / 2) + &"░░".repeat(empty / 2);
    println!("║  {:16} [{:<20}] {:5.1}%  {}  ║",
        label, bar_str, pct, count);
}

fn write_web_data() {
    fs::create_dir_all("web/data").unwrap_or_default();

    // Copy output JSONs to web/data/ for the website to consume
    let files = ["project.json", "isos.json", "variance.json"];
    for f in &files {
        let src = format!("output/{}", f);
        let dst = format!("web/data/{}", f);
        if let Ok(content) = fs::read_to_string(&src) {
            fs::write(&dst, content).unwrap_or_default();
            println!("  ✓ web/data/{}", f);
        } else {
            println!("  ⚠ {} not found — run 'cargo run export' first", src);
        }
    }

    // Write dashboard.json
    let dash = r#"{
  "generated": "2026-06-08",
  "circuit": "C-1602-O-1B",
  "kpis": {
    "iso_pct": 21.1,
    "rbic_pct": 37.1,
    "rope_pct": 0.0,
    "eru_pct": 85.1,
    "fitness": 30.6,
    "resonance_f": 0.041,
    "hours_remaining": 461.7,
    "eru_score": 851
  },
  "status": "IN_PROGRESS",
  "resonance_status": "CAPACITIVE_DOMINANT",
  "next_brick": "File daily report (ERU#46) + log 8 ISOs today"
}"#;
    fs::write("web/data/dashboard.json", dash).unwrap_or_default();
    fs::write("output/dashboard.json", dash).unwrap_or_default();
    println!("  ✓ web/data/dashboard.json");
    println!("[DASHBOARD] Complete");
}
